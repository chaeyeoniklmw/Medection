# Pill Detection > 2024-12-10 9:08pm
https://universe.roboflow.com/chaeyeon2/pill-detection-rwsvt

Provided by a Roboflow user
License: CC BY 4.0

